#If you have permission to run pip, source this file to install all the dependencies of PBSuite
#If you don't have permission to run pip, look into creating python virtualenv.
pip install numpy==1.6
pip install h5py==2.0.1
pip install pysam==0.8.0
pip install pyvcf==0.6.7
