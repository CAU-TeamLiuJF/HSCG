#ifndef RNA_SEQ_PARAMETERS_H_
#define RNA_SEQ_PARAMETERS_H_



class RNASeqParameters {
 public:
  
  

};

namespace prism {
  


}

#endif
