#ifndef COMPONENTS_SEMAPHORES_H_
#define COMPONENTS_SEMAPHORES_H_

#include "MappingSemaphores.h"

MappingSemaphores semaphores;

#endif
