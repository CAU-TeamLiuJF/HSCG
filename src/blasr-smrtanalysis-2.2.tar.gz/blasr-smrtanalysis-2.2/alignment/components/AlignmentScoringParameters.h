#ifndef ALIGNMENT_SCORING_PARAMETERS_H_
#define ALIGNMENT_SCORING_PARAMETERS_H_


#include "CommandLineParser.h"


class AlignmentScoringParameters {
 public:


  void RegisterCommandLineOptions(CommandLineParser &clp);
};


#endif
