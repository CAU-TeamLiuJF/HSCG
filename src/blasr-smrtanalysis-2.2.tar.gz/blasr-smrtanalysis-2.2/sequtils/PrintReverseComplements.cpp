#include "../common/FASTASequence.h"
#include "../common/FASTAReader.h"
#include "../common/CommandLineParser.h"


int main(int argc, char* argv[]) {

	

}
	
