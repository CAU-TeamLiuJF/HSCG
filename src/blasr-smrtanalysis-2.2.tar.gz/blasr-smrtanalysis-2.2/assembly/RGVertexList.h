#ifndef ASSEMBLY_RG_VERTEX_LIST_H_
#define ASSEMBLY_RG_VERTEX_LIST_H_


class RGVertexList {
 public:



};

#endif
