#ifndef ASSEMBLY_RG_READ_INTERVAL
#define ASSEMBLY_RG_READ_INTERVAL


class RGReadInterval {
 public:
	



};


#endif
