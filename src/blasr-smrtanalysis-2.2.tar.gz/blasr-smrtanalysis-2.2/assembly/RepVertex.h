#ifndef ASSEMBLY_REP_VERTEX_H_
#define ASSEMBLY_REP_VERTEX_H_


template<typename T_Identifier>
class Vertex {
  public:
			
			


};


#endif
