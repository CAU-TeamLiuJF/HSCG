#ifndef ASSEMBLY_RG_INTERVAL
#define ASSEMBLY_RG_INTERVAL


class RGInterval {




}


#endif
