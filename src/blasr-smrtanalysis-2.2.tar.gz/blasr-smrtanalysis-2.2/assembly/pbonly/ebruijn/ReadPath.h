#ifndef EBRUIJN_READ_PATH_H_
#define EBRUIJN_READ_PATH_H_

#include "MatchVertex.h"
#include <set>


#endif
