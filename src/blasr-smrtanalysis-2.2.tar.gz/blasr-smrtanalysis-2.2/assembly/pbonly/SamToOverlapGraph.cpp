#include "FASTAReader.h"
#include "FASTASequence.h"
#include "algorithms/alignment/readers/sam/SAMReader.h"
#include "datastructures/alignmentset/SAMAlignment.h"
#include "datastructures/alignmentset/SAMToAlignmentCandidateAdapter.h"
#include "datastructures/alignment/AlignmentCandidate.h"
#include "CommandLineParser.h"

#include <vector>
#include <string>
#include <set>

int main(int argc, char* argv[]) {
  



}
