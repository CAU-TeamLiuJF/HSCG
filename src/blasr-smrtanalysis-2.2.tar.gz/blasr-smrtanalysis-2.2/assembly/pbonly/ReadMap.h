#ifndef READ_MAP_H_
#define READ_MAP_H_

#include "Read.h"
#include <map>

using namespace std;


#endif
