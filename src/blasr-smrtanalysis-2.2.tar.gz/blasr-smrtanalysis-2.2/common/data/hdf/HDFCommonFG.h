#ifndef DATA_HDF_HDF_COMMON_FG_H_
#define DATA_HDF_HDF_COMMON_FG_H_



using namespace std;
using namespace H5;

class HDFCommonFG {
 public:

};
#endif
