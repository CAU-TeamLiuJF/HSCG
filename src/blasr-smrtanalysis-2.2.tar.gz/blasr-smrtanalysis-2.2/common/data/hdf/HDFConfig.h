#ifndef DATA_HDF_HDF_CONFIG_H_
#define DATA_HDF_HDF_CONFIG_H_

#define MAX_DIMS 10


#endif
