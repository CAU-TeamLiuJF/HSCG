#ifndef DATASTRUCTURES_READS_SENTINAL_FILE_H_
#define DATASTRUCTURES_READS_SENTINAL_FILE_H_

#include "datastructures/matrix/Matrix.h"

class SentinalFile {
 public:
  vector<string> parts;
  Matrix<unsigned int>  
  

#endif
