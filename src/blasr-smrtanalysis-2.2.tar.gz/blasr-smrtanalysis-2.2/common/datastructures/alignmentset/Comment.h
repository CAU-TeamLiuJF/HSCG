#ifndef ALIGNMENT_COMMENT_H_
#define ALIGNMENT_COMMENT_H_


class SAMComment {
 public:
  string comment;
};

#endif
