#ifndef SET_ALGORITHMS_H_
#define SET_ALGORITHMS_H_

#include <assert.h>
#include <vector>
#include <iostream>

using namespace std;

#include "algorithms/LongestIncreasingSubset.h"


#endif
