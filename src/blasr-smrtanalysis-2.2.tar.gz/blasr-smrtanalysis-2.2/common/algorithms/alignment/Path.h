#ifndef PATH_H_
#define PATH_H_

enum Arrow { Diagonal, Up, Left, NoArrow};

#endif
