#ifndef ALGORITHMS_ALIGNMENT_ALIGNMENT_FORMATS_H_
#define ALGORITHMS_ALIGNMENT_ALIGNMENT_FORMATS_H_


enum AlignmentPrintFormat { StickPrint, SummaryPrint, CompareXML, Vulgar, Interval, CompareSequencesParsable, SAM, NOFORMAT};

#endif
