#ifndef GENE_DB_LOCUS_H_
#define GENE_DB_LOCUS_H_

class GeneDBLocus {
 public:
  string geneName;
  string chromosome;
  int    startPosition;
};

#endif
