#ifndef CDNA_DUPLICATED_GENE_DB_H_
#define CDNA_DUPLICATED_GENE_DB_H_


class DuplicatedGeneDB {
 public:
  


};

#endif
