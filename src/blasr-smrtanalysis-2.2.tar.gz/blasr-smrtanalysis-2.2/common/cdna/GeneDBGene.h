#ifndef GENEDB_GENE_H_
#define GENEDB_GENE_H_

class GeneDBGene {
 public:
  


};


#endif
