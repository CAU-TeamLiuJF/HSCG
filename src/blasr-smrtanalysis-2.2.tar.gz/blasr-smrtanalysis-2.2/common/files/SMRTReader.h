#ifndef FILES_SMRT_READER_H_
#define FILES_SMRT_READER_H_


#include "ReaderAgglomerate.h"
#include <vector>


class SMRTReader {
 public:
  ReaderAgglomerate reader;
  
  



};



#endif
